from setuptools import setup

setup(
   name='package_name',
   version='0.1.0',
   packages=['package_name'],
   description='This is package_name Test',
   install_requires=[
       "requests",
   ]
)