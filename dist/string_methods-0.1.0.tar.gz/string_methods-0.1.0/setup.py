from setuptools import setup

setup(
   name='string_methods',
   version='0.1.0',
   packages=['string_methods'],
   description='This is string_methods Test',
   install_requires=[
       "requests",
   ]
)